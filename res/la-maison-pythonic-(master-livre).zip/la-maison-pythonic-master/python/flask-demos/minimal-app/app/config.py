# coding: utf8

PARAMS = { 'nom': 'Casimir', 'age' : 5 }

