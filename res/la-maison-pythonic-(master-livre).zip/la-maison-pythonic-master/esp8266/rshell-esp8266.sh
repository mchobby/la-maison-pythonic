#!/bin/bash
rshell --port /dev/ttyUSB0 --baud 115200 --buffer-size 128 --editor nano

