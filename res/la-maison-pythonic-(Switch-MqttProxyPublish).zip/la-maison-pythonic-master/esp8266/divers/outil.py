def create_list( count, init_value ):
    l = []
    for i in range( count ):
        l.append( init_value )
    return l

def add( v1, v2 ):
    return v1 + v2

COULEUR_ROSE = (255, 153, 204)

