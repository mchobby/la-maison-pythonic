#!/bin/bash
# Collecter les pilotes nécessaires 
rm ads1x15.py
wget https://raw.githubusercontent.com/mchobby/esp8266-upy/master/ads1015-ads1115/ads1x15.py
