#!/bin/bash
mosquitto_sub -h 192.168.1.210 -t "#" -v -u pusr103 -P 21052017

